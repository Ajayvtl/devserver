import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'

export default function Loading() {
  return (
    <div className="page">
      <Card>
        <Skeleton lines={3} />
      </Card>
      <Card>
        <Skeleton lines={8} />
      </Card>
    </div>
  )
}
